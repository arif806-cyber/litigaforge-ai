const BASE = "/litigaforge";

// Public endpoints that should NOT trigger a /login redirect on 401
const PUBLIC_PATH = /^\/(ask|clarify|contact|document\/analyze|documents\/paid|judgments|lawyers|legal-aid|chains|healthz|memory|stats|cases\?|research\/profile)/;

// Guard against concurrent refresh calls
let _refreshing: Promise<boolean> | null = null;

export async function _tryRefresh(): Promise<boolean> {
  if (_refreshing) return _refreshing;
  _refreshing = (async () => {
    try {
      const res = await fetch(`${BASE}/auth/refresh`, {
        method: "POST",
        credentials: "include",
      });
      return res.ok;
    } catch {
      return false;
    } finally {
      _refreshing = null;
    }
  })();
  return _refreshing;
}

type ApiFetchInit = Omit<RequestInit, "body"> & { body?: object | BodyInit | null };

export async function apiFetch(path: string, init?: ApiFetchInit) {
  const rawBody = (init as any)?.body;
  const isPlainObject =
    rawBody !== undefined &&
    rawBody !== null &&
    typeof rawBody === "object" &&
    !(rawBody instanceof FormData) &&
    !(rawBody instanceof Blob) &&
    !(rawBody instanceof URLSearchParams) &&
    !(rawBody instanceof ArrayBuffer);

  const body = isPlainObject ? JSON.stringify(rawBody) : rawBody;

  // Cookie-only auth: browser sends httpOnly cookie automatically
  // `body` is already normalised to BodyInit (string | null | Blob | …) at this point.
  const baseInit: RequestInit = {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...init?.headers,
    },
    ...(init as RequestInit),
    body: body as BodyInit | null | undefined,
  };
  const res = await fetch(`${BASE}${path}`, baseInit);

  if (res.status === 401) {
    if (!PUBLIC_PATH.test(path)) {
      // Attempt a silent token refresh and retry once
      const refreshed = await _tryRefresh();
      if (refreshed) {
        const retryInit: RequestInit = {
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
            ...init?.headers,
          },
          ...(init as RequestInit),
        };
        const retry = await fetch(`${BASE}${path}`, retryInit);
        if (!retry.ok) {
          if (retry.status === 401) {
            window.location.href = "/login";
            return;
          }
          const detail = await _extractError(retry);
          throw new Error(detail || `API error ${retry.status}`);
        }
        return retry.json();
      }
      // Refresh failed — session is truly expired
      window.location.href = "/login";
      return;
    }
    // Public endpoint 401 — fall through to error handling below
  }

  if (!res.ok) {
    const detail = await _extractError(res);
    throw new Error(detail || `API error ${res.status}`);
  }

  return res.json();
}

async function _extractError(res: Response): Promise<string> {
  try {
    const json = await res.json();
    return json?.detail ?? json?.message ?? "";
  } catch {
    return res.text();
  }
}

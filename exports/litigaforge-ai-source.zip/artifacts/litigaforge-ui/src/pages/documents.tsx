import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth-context";
import { apiFetch } from "@/lib/api";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  FileText, Download, Share2, Trash2, Upload,
  Loader2, Search, X, ArrowLeft
} from "lucide-react";
import { SEOHelmet } from "@/components/SEOHelmet";
import { PageShell } from "@/components/PageShell";
import { Button } from "@/components/ui/button";
import { useCountry } from "@/hooks/useCountry";
import { formatDate } from "@/lib/locale";
import { useToast } from "@/hooks/use-toast";

export default function DocumentsPage() {
  const { user } = useAuth();
  const { activeCode } = useCountry();
  const [, setLocation] = useLocation();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const { data, isLoading } = useQuery({
    queryKey: ["client-all-documents"],
    queryFn: () => apiFetch("/client/documents"),
    enabled: !!user,
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => apiFetch(`/client/documents/${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["client-all-documents"] }),
  });

  if (!user) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="text-center space-y-4">
          <FileText className="w-12 h-12 text-muted-foreground/40 mx-auto" />
          <h2 className="text-xl font-semibold">Sign In Required</h2>
          <Button onClick={() => setLocation("/login")}>Sign In</Button>
        </div>
      </div>
    );
  }

  const docs = (data?.documents ?? []).filter((d: any) =>
    !search || d.filename?.toLowerCase().includes(search.toLowerCase()) || d.case_title?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <PageShell title="Case Documents" subtitle="All your uploaded case files in one place.">
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => setLocation("/client-dashboard")} className="text-muted-foreground/60 hover:text-muted-foreground">
          <ArrowLeft className="w-5 h-5" />
        </button>
      </div>

      {/* ── Pinned User Guide ──────────────────────────────────────────── */}
      <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl p-4 mb-4 flex items-center gap-4"
        style={{ background: "rgba(245,183,84,0.08)", border: "1px solid rgba(245,183,84,0.25)" }}>
        <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: "rgba(245,183,84,0.2)" }}>
          <FileText className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-primary text-sm">LitigaForge AI — User Guide</p>
          <p className="text-[11px] text-muted-foreground mt-0.5">
            16-page guide covering all features — matching, AI agents, document analysis, legal aid &amp; more.
          </p>
        </div>
        <a
          href="/litigaforge/public/litigaforge_user_guide.pdf"
          download="LitigaForge_User_Guide.pdf"
          className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-white font-semibold text-[11px] flex-shrink-0 transition-opacity hover:opacity-90"
          style={{ background: "#d97706" }}
        >
          <Download className="w-3.5 h-3.5" />
          Download PDF
        </a>
      </motion.div>

      <div className="bg-card rounded-2xl shadow-sm" style={{ border: "1px solid hsl(var(--border))" }}>
        {/* Header + Search */}
        <div className="px-5 py-4 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-3" style={{ borderColor: "hsl(var(--border))" }}>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "rgba(139,92,246,0.12)" }}>
              <FileText className="w-4 h-4 text-violet-400" />
            </div>
            <h2 className="font-bold text-foreground text-sm">All Documents</h2>
            <span className="text-[11px] text-muted-foreground/60">({data?.total ?? 0})</span>
          </div>
          <div className="flex items-center gap-2">
            <label className="flex items-center gap-1.5 text-[11px] font-semibold px-3 py-1.5 rounded-lg text-white cursor-pointer transition-colors" style={{ background: "#2563EB" }}>
              <Upload className="w-3.5 h-3.5" />
              {uploading ? "Uploading..." : "Upload"}
              <input type="file" className="hidden" disabled={uploading}
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  setUploading(true);
                  try {
                    const form = new FormData();
                    form.append("file", file);
                    const token = typeof window !== "undefined" ? localStorage.getItem("lf_token") : null;
                    const res = await fetch(`/litigaforge/client/cases/0/documents`, {
                      method: "POST",
                      headers: token ? { Authorization: `Bearer ${token}` } : {},
                      body: form,
                    });
                    if (!res.ok) throw new Error("Upload failed");
                    qc.invalidateQueries({ queryKey: ["client-all-documents"] });
                  } catch (err) {
                    toast({ title: "Upload failed", description: err instanceof Error ? err.message : "Could not upload document. Please try again.", variant: "destructive" });
                  } finally {
                    setUploading(false);
                    e.target.value = "";
                  }
                }}
              />
            </label>
          </div>
        </div>
        <div className="px-5 py-3 border-b" style={{ borderColor: "hsl(var(--border))" }}>
          <div className="flex items-center gap-2 bg-background rounded-lg px-3 py-2">
            <Search className="w-4 h-4 text-muted-foreground/60" />
            <input type="text" placeholder="Search by filename or case name..." value={search} onChange={(e) => setSearch(e.target.value)}
              className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground/60 outline-none" />
            {search && <button onClick={() => setSearch("")} className="text-muted-foreground/60 hover:text-muted-foreground"><X className="w-4 h-4" /></button>}
          </div>
        </div>

        {/* Document list */}
        <div className="p-4 space-y-2.5">
          {isLoading && <div className="py-8 text-center"><Loader2 className="w-5 h-5 animate-spin mx-auto text-muted-foreground/60" /></div>}
          {!isLoading && docs.length === 0 && (
            <div className="rounded-xl p-8 text-center" style={{ background: "hsl(var(--muted))", border: "1px dashed hsl(var(--border))" }}>
              <FileText className="w-10 h-10 text-muted-foreground/40 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No documents yet.</p>
              <p className="text-xs text-muted-foreground/60 mt-1">Upload files from a case detail page.</p>
            </div>
          )}
          {docs.map((doc: any) => (
            <motion.div key={doc.id} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
              className="rounded-xl p-4 hover:shadow-sm transition-all" style={{ background: "hsl(var(--muted))", border: "1px solid hsl(var(--border))" }}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: "rgba(139,92,246,0.12)" }}>
                    <FileText className="w-5 h-5 text-violet-400" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-foreground text-sm">{doc.filename}</p>
                    <div className="flex items-center gap-3 mt-1 text-[11px] text-muted-foreground/60">
                      <span className="text-primary font-medium uppercase">{doc.file_type}</span>
                      <span>{doc.file_size ? (doc.file_size / 1024).toFixed(1) + " KB" : "N/A"}</span>
                      <span>{formatDate(doc.created_at, activeCode)}</span>
                      {doc.case_title && <span className="text-muted-foreground">Case: {doc.case_title}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <a href={doc.file_url} download={doc.filename}
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground/60 hover:text-primary hover:bg-primary/10 transition-colors" title="Download">
                    <Download className="w-3.5 h-3.5" />
                  </a>
                  <button onClick={() => {
                    const text = `Document: ${doc.filename}\n${doc.case_title ? `Case: ${doc.case_title}\n` : ""}Download: ${typeof window !== "undefined" ? window.location.origin : ""}${doc.file_url}\n\n— LitigaForge AI`;
                    if (navigator.share) navigator.share({ title: doc.filename, text });
                    else window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
                  }}
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground/60 hover:text-emerald-400 hover:bg-emerald-500/10 transition-colors" title="Share">
                    <Share2 className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => {
                    if (!confirm(`Delete "${doc.filename}"?`)) return;
                    deleteMut.mutate(doc.id);
                  }}
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-muted-foreground/60 hover:text-red-400 hover:bg-red-500/10 transition-colors" title="Delete">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </PageShell>
  );
}

import React, { useState, useEffect } from "react";
import { AreaChart, Area, ResponsiveContainer } from "recharts";
import {
  Scale, MessageSquareText, FileSearch2, Gavel, FileText, Users, HandHeart,
  Tags, Menu, Plus, Briefcase, Inbox, MoreHorizontal, ChevronRight, Star,
  Wallet, ClipboardList, CalendarClock, Sparkles, ToggleRight, ToggleLeft,
  BadgeCheck, Mic, TrendingUp, CheckCircle2, UploadCloud, UserCheck2, Zap,
  Boxes, UserSearch, Radar, FileSignature, Building2, User, Globe, Bell,
  HelpCircle, LogOut, X,
} from "lucide-react";

const bg = "#0A0B10";
const surface = "#14151F";
const surfaceBorder = "rgba(255,255,255,0.08)";
const textPrimary = "#F5F5F7";
const textSoft = "#8A8FA3";
const amber = "#F5B754";
const amberDim = "rgba(245,183,84,0.14)";
const emerald = "#34D399";
const emeraldDim = "rgba(52,211,153,0.14)";
const violet = "#8B5CF6";
const violetDim = "rgba(139,92,246,0.16)";

const serif = "Source Serif 4, Georgia, serif";
const sans = "Inter, system-ui, sans-serif";
const mono = "IBM Plex Mono, monospace";

const sparkData = [4, 6, 5, 8, 7, 11, 9, 14, 12, 17].map((v, i) => ({ i, v }));

function Glass({ className = "", style = {}, children, ...rest }: any) {
  return (
    <div
      className={`rounded-2xl backdrop-blur-md ${className}`}
      style={{ backgroundColor: "rgba(255,255,255,0.035)", border: `1px solid ${surfaceBorder}`, ...style }}
      {...rest}
    >
      {children}
    </div>
  );
}

function Ring({ value, color, size = 74, label, sub }: any) {
  const [animated, setAnimated] = useState(0);
  const r = (size - 10) / 2;
  const c = 2 * Math.PI * r;
  useEffect(() => {
    const t = setTimeout(() => setAnimated(value), 150);
    return () => clearTimeout(t);
  }, [value]);
  return (
    <div className="flex items-center gap-3">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,0.08)" strokeWidth="7" fill="none" />
          <circle
            cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth="7" fill="none"
            strokeLinecap="round"
            strokeDasharray={c}
            strokeDashoffset={c - (animated / 100) * c}
            style={{ transition: "stroke-dashoffset 1.1s cubic-bezier(.4,0,.2,1)", filter: `drop-shadow(0 0 6px ${color}99)` }}
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center text-sm font-bold" style={{ color: textPrimary, fontFamily: mono }}>
          {value}%
        </span>
      </div>
      <div>
        <p className="text-xs font-semibold" style={{ color: textPrimary }}>{label}</p>
        <p className="text-[10px]" style={{ color: textSoft }}>{sub}</p>
      </div>
    </div>
  );
}

function Sparkline({ color }: any) {
  const gradId = `grad-${color.replace("#", "")}`;
  return (
    <div style={{ width: "100%", height: 34 }}>
      <ResponsiveContainer>
        <AreaChart data={sparkData}>
          <defs>
            <linearGradient id={gradId} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={color} stopOpacity={0.5} />
              <stop offset="100%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <Area type="monotone" dataKey="v" stroke={color} strokeWidth={2} fill={`url(#${gradId})`} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function Typewriter({ text, accent }: any) {
  const [shown, setShown] = useState("");
  useEffect(() => {
    setShown("");
    let i = 0;
    const id = setInterval(() => {
      i++;
      setShown(text.slice(0, i));
      if (i >= text.length) clearInterval(id);
    }, 22);
    return () => clearInterval(id);
  }, [text]);
  return (
    <p className="text-xs leading-relaxed" style={{ color: textPrimary, fontFamily: sans, minHeight: "2.6em" }}>
      {shown}
      <span className="inline-block w-1 h-3 ml-0.5 align-middle animate-pulse" style={{ backgroundColor: accent }} />
    </p>
  );
}

function FileTab({ icon: Icon, title, desc, accent }: any) {
  return (
    <button
      className="relative text-left w-full rounded-xl p-3.5 flex flex-col gap-2.5 active:scale-[0.97] transition-transform"
      style={{ backgroundColor: "rgba(255,255,255,0.035)", border: `1px solid ${surfaceBorder}` }}
    >
      <span className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: accent.dim }}>
        <Icon size={16} color={accent.solid} strokeWidth={2} />
      </span>
      <span>
        <span className="block font-semibold text-[13px] leading-snug" style={{ color: textPrimary }}>{title}</span>
        <span className="block text-[11px] mt-0.5 leading-snug" style={{ color: textSoft }}>{desc}</span>
      </span>
    </button>
  );
}

function Chip({ label, accent }: any) {
  return (
    <button
      className="flex-shrink-0 px-3 py-1.5 rounded-full text-[11px] font-medium active:scale-95 transition-transform"
      style={{ backgroundColor: accent.dim, color: accent.solid, border: `1px solid ${accent.solid}33` }}
    >
      {label}
    </button>
  );
}

function TimelineRow({ icon: Icon, title, time, color }: any) {
  return (
    <div className="flex gap-3">
      <div className="flex flex-col items-center">
        <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${color}22` }}>
          <Icon size={12} color={color} strokeWidth={2.4} />
        </span>
        <span className="w-px flex-1" style={{ backgroundColor: surfaceBorder }} />
      </div>
      <div className="pb-4">
        <p className="text-xs font-medium" style={{ color: textPrimary }}>{title}</p>
        <p className="text-[10px] mt-0.5" style={{ color: textSoft }}>{time}</p>
      </div>
    </div>
  );
}

function StatChip({ icon: Icon, value, label, accent }: any) {
  return (
    <Glass className="flex-1 px-3 py-3 flex flex-col gap-1.5">
      <Icon size={14} color={accent} strokeWidth={2.2} />
      <span className="text-base font-bold" style={{ color: textPrimary, fontFamily: mono }}>{value}</span>
      <span className="text-[10px]" style={{ color: textSoft }}>{label}</span>
    </Glass>
  );
}

function NavItem({ icon: Icon, label, active, accent, onClick }: any) {
  return (
    <button onClick={onClick} className="flex flex-col items-center justify-center gap-1 flex-1 py-1.5">
      <Icon size={20} strokeWidth={active ? 2.4 : 1.8} color={active ? accent : "#565A6E"} style={active ? { filter: `drop-shadow(0 0 5px ${accent}99)` } : {}} />
      <span className="text-[10px] leading-none" style={{ color: active ? accent : "#565A6E", fontWeight: active ? 600 : 500 }}>{label}</span>
    </button>
  );
}

function RoleSwitch({ role, setRole }: any) {
  return (
    <div className="px-4 pt-3 pb-1">
      <div className="relative flex rounded-full p-1" style={{ backgroundColor: "rgba(255,255,255,0.06)" }}>
        <div
          className="absolute top-1 bottom-1 rounded-full transition-all duration-300"
          style={{
            width: "calc(50% - 4px)",
            left: role === "client" ? "4px" : "calc(50% + 0px)",
            backgroundColor: role === "client" ? amber : emerald,
            boxShadow: `0 0 14px ${role === "client" ? amber : emerald}66`,
          }}
        />
        <button onClick={() => setRole("client")} className="relative z-10 flex-1 py-1.5 text-xs font-semibold" style={{ color: role === "client" ? "#0A0B10" : textSoft }}>
          Client
        </button>
        <button onClick={() => setRole("advocate")} className="relative z-10 flex-1 py-1.5 text-xs font-semibold" style={{ color: role === "advocate" ? "#0A0B10" : textSoft }}>
          Advocate
        </button>
      </div>
    </div>
  );
}

function MenuRow({ icon: Icon, title, desc, accent, tag }: any) {
  return (
    <button className="w-full flex items-center gap-3 px-4 py-3 active:bg-white/5 transition-colors rounded-xl">
      <span className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: accent.dim }}>
        <Icon size={16} color={accent.solid} strokeWidth={2} />
      </span>
      <span className="flex-1 text-left">
        <span className="flex items-center gap-1.5">
          <span className="text-[13px] font-semibold" style={{ color: textPrimary }}>{title}</span>
          {tag && (
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded" style={{ backgroundColor: violetDim, color: violet }}>{tag}</span>
          )}
        </span>
        <span className="block text-[11px] mt-0.5" style={{ color: textSoft }}>{desc}</span>
      </span>
      <ChevronRight size={15} color={textSoft} />
    </button>
  );
}

function MoreSheet({ role, open, onClose }: any) {
  const accent = role === "client" ? { solid: amber, dim: amberDim } : { solid: emerald, dim: emeraldDim };
  const clientAdvanced = [
    { icon: Boxes, title: "Forge Workspace", desc: "Build multi-agent case workflows on a canvas.", tag: "CORE", accent: { solid: violet, dim: violetDim } },
    { icon: UserSearch, title: "Smart Client Intake", desc: "AI structures your case before it's posted." },
    { icon: Radar, title: "Opponent Intelligence", desc: "Background on the other party, where available." },
    { icon: FileSignature, title: "Auto Vakalatnama", desc: "Generate advocate authorization instantly." },
    { icon: Building2, title: "Property Case Autopilot", desc: "End-to-end tracking for property disputes." },
  ];
  const advocateAdvanced = [
    { icon: Boxes, title: "Forge Workspace", desc: "Build multi-agent case workflows on a canvas.", tag: "CORE", accent: { solid: violet, dim: violetDim } },
    { icon: Radar, title: "Opponent Intelligence", desc: "Background research for the opposing party." },
    { icon: FileSignature, title: "Auto Vakalatnama", desc: "Generate authorizations for new clients." },
    { icon: Building2, title: "Property Case Autopilot", desc: "Automated tracking for property matters." },
  ];
  const account = [
    { icon: User, title: "Profile & Verification", desc: role === "client" ? "Manage your details" : "Bar council ID, credentials" },
    { icon: Globe, title: "Language & Region", desc: "English · India" },
    { icon: Bell, title: "Notifications", desc: "Manage alerts & reminders" },
    { icon: HelpCircle, title: "Help & Support", desc: "FAQs, contact, live chat" },
  ];
  return (
    <>
      <div
        className={`fixed inset-0 z-40 transition-opacity duration-300 ${open ? "opacity-100" : "opacity-0 pointer-events-none"}`}
        style={{ backgroundColor: "rgba(0,0,0,0.6)", backdropFilter: "blur(2px)" }}
        onClick={onClose}
      />
      <div
        className={`fixed left-0 right-0 bottom-0 z-50 mx-auto transition-transform duration-300 ease-out ${open ? "translate-y-0" : "translate-y-full"}`}
        style={{ maxWidth: 420, maxHeight: "82vh", backgroundColor: surface, borderTop: `1px solid ${surfaceBorder}`, borderTopLeftRadius: 24, borderTopRightRadius: 24, overflowY: "auto" }}
      >
        <div className="flex justify-center pt-3">
          <span className="w-9 h-1 rounded-full" style={{ backgroundColor: "rgba(255,255,255,0.2)" }} />
        </div>
        <div className="flex items-center justify-between px-4 pt-2 pb-1">
          <h2 className="text-sm font-bold" style={{ color: textPrimary, fontFamily: serif }}>More</h2>
          <button onClick={onClose} className="w-7 h-7 rounded-full flex items-center justify-center" style={{ backgroundColor: "rgba(255,255,255,0.06)" }}>
            <X size={14} color={textSoft} />
          </button>
        </div>
        <div className="px-2 pt-2">
          <p className="px-3 pb-1 text-[10px] font-semibold tracking-widest uppercase" style={{ color: textSoft }}>Advanced Tools</p>
          {(role === "client" ? clientAdvanced : advocateAdvanced).map((f) => (
            <MenuRow key={f.title} {...f} accent={(f as any).accent || accent} />
          ))}
        </div>
        <div className="px-2 pt-3 pb-2">
          <p className="px-3 pb-1 text-[10px] font-semibold tracking-widest uppercase" style={{ color: textSoft }}>Account</p>
          {account.map((f) => (
            <MenuRow key={f.title} {...f} accent={{ solid: textSoft, dim: "rgba(255,255,255,0.06)" }} />
          ))}
          <button className="w-full flex items-center gap-3 px-4 py-3 active:bg-white/5 transition-colors rounded-xl">
            <span className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: "rgba(239,68,68,0.14)" }}>
              <LogOut size={16} color="#EF4444" strokeWidth={2} />
            </span>
            <span className="text-[13px] font-semibold" style={{ color: "#EF4444" }}>Log Out</span>
          </button>
        </div>
        <div style={{ height: "env(safe-area-inset-bottom)" }} />
      </div>
    </>
  );
}

export function Dashboard() {
  const [role, setRole] = useState<"client" | "advocate">("client");
  const [available, setAvailable] = useState(true);
  const [listening, setListening] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("home");
  const accent = role === "client" ? { solid: amber, dim: amberDim } : { solid: emerald, dim: emeraldDim };

  const clientTools = [
    { icon: MessageSquareText, title: "Ask a Lawyer", desc: "AI-backed answers, instantly." },
    { icon: FileSearch2, title: "Document Analyzer", desc: "Risk-flagged in minutes." },
    { icon: Gavel, title: "Judgment Finder", desc: "Search the Indian Kanoon corpus." },
    { icon: FileText, title: "Free Documents", desc: "Ready-to-use templates." },
  ];
  const clientHelp = [
    { icon: Users, title: "Find a Lawyer", desc: "Matched by specialty & rating." },
    { icon: Plus, title: "Post a Case", desc: "Hear back from advocates." },
    { icon: HandHeart, title: "Free Legal Aid", desc: "For those who qualify." },
    { icon: Tags, title: "Pricing", desc: "Transparent plans." },
  ];
  const advocateTools = [
    { icon: ClipboardList, title: "Match Proposals", desc: "3 new cases matched today." },
    { icon: Briefcase, title: "My Cases", desc: "Track matters end to end." },
    { icon: FileSearch2, title: "Document Vault", desc: "Client files, by case." },
    { icon: Gavel, title: "Judgment Finder", desc: "Search case law fast." },
  ];
  const advocatePractice = [
    { icon: Wallet, title: "Earnings", desc: "Payouts & pending invoices." },
    { icon: CalendarClock, title: "Availability", desc: "Set your booking hours." },
    { icon: BadgeCheck, title: "Verification", desc: "Bar council ID on file." },
    { icon: Tags, title: "Pricing Plans", desc: "Manage consultation rates." },
  ];

  return (
    <div className="min-h-screen w-full flex justify-center" style={{ backgroundColor: "#000000", fontFamily: sans }}>
      <div className="w-full relative flex flex-col" style={{ maxWidth: 420, backgroundColor: bg, minHeight: "100vh" }}>

        {/* ambient glow */}
        <div className="absolute top-0 left-0 right-0 h-64 pointer-events-none" style={{ background: `radial-gradient(ellipse at top, ${accent.solid}22, transparent 70%)` }} />

        {/* header */}
        <header className="sticky top-0 z-20" style={{ backgroundColor: "rgba(10,11,16,0.85)", backdropFilter: "blur(12px)" }}>
          <div className="flex items-center justify-between px-4 pt-3 pb-1">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: accent.solid, boxShadow: `0 0 16px ${accent.solid}77` }}>
                <Scale size={16} color="#0A0B10" strokeWidth={2.4} />
              </span>
              <span className="text-base tracking-tight" style={{ color: textPrimary, fontFamily: serif, fontWeight: 600 }}>LitigaForge</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="relative flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-semibold" style={{ backgroundColor: violetDim, color: violet }}>
                <span className="w-1.5 h-1.5 rounded-full animate-ping absolute left-2" style={{ backgroundColor: violet }} />
                <span className="w-1.5 h-1.5 rounded-full ml-1.5" style={{ backgroundColor: violet }} />
                <span className="ml-0.5">AI LIVE</span>
              </span>
              <Menu size={20} color={textSoft} />
            </div>
          </div>
          <RoleSwitch role={role} setRole={setRole} />
        </header>

        {/* CLIENT VIEW */}
        {role === "client" && (
          <main className="relative flex-1 px-4 pt-5 pb-28 flex flex-col gap-5">
            <Glass className="p-4">
              <div className="flex items-center justify-between mb-3">
                <Ring value={82} color={amber} label="Match Confidence" sub="Based on your case details" />
                <span className="flex items-center gap-1 text-[10px] font-semibold px-2 py-1 rounded-full" style={{ color: amber, backgroundColor: amberDim }}>
                  <TrendingUp size={11} /> +18%
                </span>
              </div>
              <Sparkline color={amber} />
              <div className="flex items-center justify-between mt-3">
                <p className="text-[11px]" style={{ color: textSoft }}>Advocate views, last 7 days</p>
                <button className="flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold active:scale-95 transition-transform" style={{ backgroundColor: amber, color: "#0A0B10" }}>
                  <Plus size={14} strokeWidth={2.8} /> Post a Case
                </button>
              </div>
            </Glass>

            <Glass className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles size={13} color={violet} />
                <p className="text-[11px] font-semibold tracking-wide uppercase" style={{ color: violet }}>Ask a Lawyer · AI</p>
              </div>
              <Typewriter accent={violet} text="Under the Rent Control Act, your landlord must provide 30 days' written notice before eviction..." />
              <div className="flex items-center gap-2 mt-3">
                <button
                  onClick={() => setListening(!listening)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${listening ? "animate-pulse" : ""}`}
                  style={{ backgroundColor: listening ? violet : violetDim }}
                >
                  <Mic size={15} color={listening ? "#0A0B10" : violet} strokeWidth={2.2} />
                </button>
                <div className="flex-1 rounded-full px-3 py-2 text-[11px]" style={{ backgroundColor: "rgba(255,255,255,0.05)", color: textSoft }}>
                  {listening ? "Listening…" : "Ask anything about your case"}
                </div>
              </div>
              <div className="flex gap-2 mt-3 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
                <Chip label="Draft rent agreement" accent={{ solid: violet, dim: violetDim }} />
                <Chip label="Check property title" accent={{ solid: violet, dim: violetDim }} />
                <Chip label="Find criminal lawyer" accent={{ solid: violet, dim: violetDim }} />
              </div>
            </Glass>

            <section>
              <div className="flex items-center justify-between mb-2.5">
                <h2 className="text-[11px] font-semibold tracking-widest uppercase" style={{ color: textSoft }}>Legal Tools</h2>
                <ChevronRight size={13} color={textSoft} />
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {clientTools.map((t) => <FileTab key={t.title} {...t} accent={{ solid: violet, dim: violetDim }} />)}
              </div>
            </section>

            <section>
              <div className="flex items-center justify-between mb-2.5">
                <h2 className="text-[11px] font-semibold tracking-widest uppercase" style={{ color: textSoft }}>Find Help</h2>
                <ChevronRight size={13} color={textSoft} />
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {clientHelp.map((t) => <FileTab key={t.title} {...t} accent={{ solid: amber, dim: amberDim }} />)}
              </div>
            </section>

            <section>
              <h2 className="text-[11px] font-semibold tracking-widest uppercase mb-3" style={{ color: textSoft }}>Activity</h2>
              <Glass className="p-4">
                <TimelineRow icon={UploadCloud} title="Document uploaded to case file" time="2 hours ago" color={amber} />
                <TimelineRow icon={Zap} title="AI matched 2 advocates to your case" time="Yesterday" color={violet} />
                <TimelineRow icon={CheckCircle2} title="Profile verified" time="3 days ago" color={emerald} />
              </Glass>
            </section>
          </main>
        )}

        {/* ADVOCATE VIEW */}
        {role === "advocate" && (
          <main className="relative flex-1 px-4 pt-5 pb-28 flex flex-col gap-5">
            <Glass className="p-4">
              <div className="flex items-center justify-between mb-3">
                <Ring value={91} color={emerald} label="Practice Pulse" sub="Response rate & rating combined" />
                <span className="flex items-center gap-1 text-[10px] font-semibold px-2 py-1 rounded-full" style={{ color: emerald, backgroundColor: emeraldDim }}>
                  <TrendingUp size={11} /> +6%
                </span>
              </div>
              <Sparkline color={emerald} />
              <p className="text-[11px] mt-2" style={{ color: textSoft }}>Case volume, last 7 days</p>
            </Glass>

            <Glass className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles size={13} color={violet} />
                <p className="text-[11px] font-semibold tracking-wide uppercase" style={{ color: violet }}>New Match · AI</p>
              </div>
              <Typewriter accent={violet} text="Property dispute, Hyderabad — 87% fit to your specialty. Client budget matches your standard rate." />
              <button className="mt-3 flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-semibold active:scale-95 transition-transform" style={{ backgroundColor: violet, color: "#0A0B10" }}>
                <ClipboardList size={14} strokeWidth={2.8} /> Review Proposal
              </button>
            </Glass>

            <section className="flex gap-2.5">
              <StatChip icon={Briefcase} value="6" label="Active cases" accent={emerald} />
              <StatChip icon={ClipboardList} value="3" label="Proposals" accent={emerald} />
              <StatChip icon={Star} value="4.8" label="Rating" accent={emerald} />
              <StatChip icon={Wallet} value="₹42k" label="This month" accent={emerald} />
            </section>

            <Glass className="px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <UserCheck2 size={16} color={emerald} />
                <div>
                  <p className="text-xs font-semibold" style={{ color: textPrimary }}>Accepting new cases</p>
                  <p className="text-[10px]" style={{ color: textSoft }}>{available ? "Visible to matching clients" : "Hidden from new matches"}</p>
                </div>
              </div>
              <button onClick={() => setAvailable(!available)}>
                {available
                  ? <ToggleRight size={28} color={emerald} />
                  : <ToggleLeft size={28} color={textSoft} />}
              </button>
            </Glass>

            <section>
              <div className="flex items-center justify-between mb-2.5">
                <h2 className="text-[11px] font-semibold tracking-widest uppercase" style={{ color: textSoft }}>Case Management</h2>
                <ChevronRight size={13} color={textSoft} />
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {advocateTools.map((t) => <FileTab key={t.title} {...t} accent={{ solid: emerald, dim: emeraldDim }} />)}
              </div>
            </section>

            <section>
              <div className="flex items-center justify-between mb-2.5">
                <h2 className="text-[11px] font-semibold tracking-widest uppercase" style={{ color: textSoft }}>Practice</h2>
                <ChevronRight size={13} color={textSoft} />
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {advocatePractice.map((t) => <FileTab key={t.title} {...t} accent={{ solid: amber, dim: amberDim }} />)}
              </div>
            </section>

            <section>
              <h2 className="text-[11px] font-semibold tracking-widest uppercase mb-3" style={{ color: textSoft }}>Activity</h2>
              <Glass className="p-4">
                <TimelineRow icon={Inbox} title="New case proposal received" time="1 hour ago" color={emerald} />
                <TimelineRow icon={Zap} title="Hearing reminder: Sharma vs. State" time="Tomorrow 10 AM" color={amber} />
                <TimelineRow icon={CheckCircle2} title="Payment received ₹8,500" time="2 days ago" color={emerald} />
              </Glass>
            </section>
          </main>
        )}

        {/* bottom nav */}
        <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full z-30 flex items-center" style={{ maxWidth: 420, backgroundColor: "rgba(10,11,16,0.92)", backdropFilter: "blur(16px)", borderTop: `1px solid ${surfaceBorder}`, paddingBottom: "env(safe-area-inset-bottom)" }}>
          <NavItem icon={Scale} label="Home" active={activeTab === "home"} accent={accent.solid} onClick={() => setActiveTab("home")} />
          <NavItem icon={Briefcase} label="Cases" active={activeTab === "cases"} accent={accent.solid} onClick={() => setActiveTab("cases")} />
          <NavItem icon={Inbox} label="Inbox" active={activeTab === "inbox"} accent={accent.solid} onClick={() => setActiveTab("inbox")} />
          <NavItem icon={MoreHorizontal} label="More" active={moreOpen} accent={accent.solid} onClick={() => setMoreOpen(true)} />
        </nav>

        <MoreSheet role={role} open={moreOpen} onClose={() => setMoreOpen(false)} />
      </div>
    </div>
  );
}
